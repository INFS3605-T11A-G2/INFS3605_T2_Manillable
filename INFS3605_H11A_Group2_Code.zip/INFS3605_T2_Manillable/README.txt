Welcome to our INFS3605_H11A_Group2 Application Manillable

In order for this application to run, here are essential details that you need.

Login Details:
User: test@gmail.com
Pasword: tester

In order for this appplicaiton to run, its requires a google play-enabled emulator
